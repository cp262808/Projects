import { redirect } from "next/navigation";

export default function Page() { redirect("/topics/logging-and-monitoring/intro"); }
