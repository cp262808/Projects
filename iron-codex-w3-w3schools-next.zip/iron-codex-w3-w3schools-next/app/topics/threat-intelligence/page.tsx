import { redirect } from "next/navigation";

export default function Page() { redirect("/topics/threat-intelligence/intro"); }
