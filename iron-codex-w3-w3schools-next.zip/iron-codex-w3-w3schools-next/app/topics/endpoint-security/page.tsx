import { redirect } from "next/navigation";

export default function Page() { redirect("/topics/endpoint-security/intro"); }
