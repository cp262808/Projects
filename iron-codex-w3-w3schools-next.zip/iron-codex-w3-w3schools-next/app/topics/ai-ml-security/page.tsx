import { redirect } from "next/navigation";

export default function Page() { redirect("/topics/ai-ml-security/intro"); }
