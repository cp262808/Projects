import { redirect } from "next/navigation";

export default function Page() { redirect("/topics/threat-modeling/intro"); }
