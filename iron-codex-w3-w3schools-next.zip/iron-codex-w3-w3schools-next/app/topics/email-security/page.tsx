import { redirect } from "next/navigation";

export default function Page() { redirect("/topics/email-security/intro"); }
