import { redirect } from "next/navigation";

export default function Page() { redirect("/topics/cloud-security/intro"); }
