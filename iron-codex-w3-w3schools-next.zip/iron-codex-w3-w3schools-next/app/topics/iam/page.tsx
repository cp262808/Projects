import { redirect } from "next/navigation";

export default function Page() { redirect("/topics/iam/intro"); }
