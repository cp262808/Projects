import { redirect } from "next/navigation";

export default function Page() { redirect("/topics/secrets-management/intro"); }
