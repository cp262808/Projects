import { redirect } from "next/navigation";

export default function Page() {
  redirect("/topics/compliance-audit/intro");
}
