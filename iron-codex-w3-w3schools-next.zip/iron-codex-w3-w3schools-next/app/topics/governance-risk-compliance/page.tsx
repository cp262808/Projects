import { redirect } from "next/navigation";

export default function Page() { redirect("/topics/governance-risk-compliance/intro"); }
