// Replace your current app/page.tsx with this to use the new landing.
'use client';
import React from "react";
import HomeLanding from "@/components/HomeLanding";

export default function Page() {
  return <HomeLanding />;
}
