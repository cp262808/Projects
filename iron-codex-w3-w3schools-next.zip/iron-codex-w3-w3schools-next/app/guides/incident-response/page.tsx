import { redirect } from "next/navigation";

export default function Page() { redirect("/guides/incident-response/intro"); }
