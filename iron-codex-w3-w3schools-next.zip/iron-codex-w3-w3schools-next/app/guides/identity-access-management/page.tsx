import { redirect } from "next/navigation";

export default function Page() {
  redirect("/guides/identity-access-management/intro");
}
