import { redirect } from "next/navigation";

export default function Page() { redirect("/guides/saas-security/intro"); }
