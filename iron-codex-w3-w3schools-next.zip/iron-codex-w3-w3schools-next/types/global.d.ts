declare type Slug = string;
